/* eslint-disable */
frappe.listview_settings['{doctype}'] = {{
	// add_fields: ["status"],
	// filters:[["status","=", "Open"]]
}};
