frappe.ready(function() {
	// bind events here
})