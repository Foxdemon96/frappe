# -*- coding: utf-8 -*-

from __future__ import unicode_literals

source_link = "https://github.com/frappe/frappe"
docs_base_url = "/docs"
